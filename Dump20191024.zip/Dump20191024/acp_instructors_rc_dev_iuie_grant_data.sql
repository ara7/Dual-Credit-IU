-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: acp_instructors_rc_dev
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `iuie_grant_data`
--

DROP TABLE IF EXISTS `iuie_grant_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iuie_grant_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `PRSN_UNIV_ID` varchar(255) NOT NULL DEFAULT '',
  `grant_name` varchar(255) NOT NULL DEFAULT '',
  `grant_account` varchar(255) NOT NULL DEFAULT '',
  `amount_total` varchar(255) NOT NULL DEFAULT '',
  `campus` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iuie_grant_data`
--

LOCK TABLES `iuie_grant_data` WRITE;
/*!40000 ALTER TABLE `iuie_grant_data` DISABLE KEYS */;
INSERT INTO `iuie_grant_data` VALUES (1,'2009562765','IDOE','4720720',' 1,560.00 ','IUKOA'),(2,'2008652431','IDOE','4720720',' 1,170.00 ','IUKOA'),(3,'2007189498','IDOE','4720720',' 1,170.00 ','IUKOA'),(4,'2008052402','STEM','4820000',' 1,348.99 ','IUBLA'),(5,'2009394657','STEM','4820000',' 1,170.00 ','IUSEA'),(6,'2008473714','STEM','4820000',' 1,560.00 ','IUEAA'),(7,'2006846162','ACP','2720000',' 1,612.68 ','IUEAA'),(8,'0000934748','ACP','2720000',' 1,170.00 ','IUEAA');
/*!40000 ALTER TABLE `iuie_grant_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-24 10:08:00
