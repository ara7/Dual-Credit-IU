-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: acp_instructors_rc_dev
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `iuie_academic_terms`
--

DROP TABLE IF EXISTS `iuie_academic_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iuie_academic_terms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `acad_term_cd` varchar(255) NOT NULL DEFAULT '',
  `acad_term` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iuie_academic_terms`
--

LOCK TABLES `iuie_academic_terms` WRITE;
/*!40000 ALTER TABLE `iuie_academic_terms` DISABLE KEYS */;
INSERT INTO `iuie_academic_terms` VALUES (1,'3902','Spring 1990'),(2,'3905','Summer 1990'),(3,'3908','Fall 1990'),(4,'3912','Spring 1991'),(5,'3915','Summer 1991'),(6,'3918','Fall 1991'),(7,'3922','Spring 1992'),(8,'3925','Summer 1992'),(9,'3928','Fall 1992'),(10,'3932','Spring 1993'),(11,'3935','Summer 1993'),(12,'3938','Fall 1993'),(13,'3942','Spring 1994'),(14,'3945','Summer 1994'),(15,'3948','Fall 1994'),(16,'3952','Spring 1995'),(17,'3955','Summer 1995'),(18,'3958','Fall 1995'),(19,'3962','Spring 1996'),(20,'3965','Summer 1996'),(21,'3968','Fall 1996'),(22,'3972','Spring 1997'),(23,'3975','Summer 1997'),(24,'3978','Fall 1997'),(25,'3982','Spring 1998'),(26,'3985','Summer 1998'),(27,'3988','Fall 1998'),(28,'3992','Spring 1999'),(29,'3995','Summer 1999'),(30,'3998','Fall 1999'),(31,'4002','Spring 2000'),(32,'4005','Summer 2000'),(33,'4008','Fall 2000'),(34,'4012','Spring 2001'),(35,'4015','Summer 2001'),(36,'4018','Fall 2001'),(37,'4022','Spring 2002'),(38,'4025','Summer 2002'),(39,'4028','Fall 2002'),(40,'4032','Spring 2003'),(41,'4035','Summer 2003'),(42,'4038','Fall 2003'),(43,'4042','Spring 2004'),(44,'4045','Summer 2004'),(45,'4048','Fall 2004'),(46,'4052','Spring 2005'),(47,'4055','Summer 2005'),(48,'4058','Fall 2005'),(49,'4062','Spring 2006'),(50,'4065','Summer 2006'),(51,'4068','Fall 2006'),(52,'4072','Spring 2007'),(53,'4075','Summer 2007'),(54,'4078','Fall 2007'),(55,'4082','Spring 2008'),(56,'4085','Summer 2008'),(57,'4088','Fall 2008'),(58,'4092','Spring 2009'),(59,'4095','Summer 2009'),(60,'4098','Fall 2009'),(61,'4102','Spring 2010'),(62,'4105','Summer 2010'),(63,'4108','Fall 2010'),(64,'4112','Spring 2011'),(65,'4115','Summer 2011'),(66,'4118','Fall 2011'),(67,'4122','Spring 2012'),(68,'4125','Summer 2012'),(69,'4128','Fall 2012'),(70,'4132','Spring 2013'),(71,'4135','Summer 2013'),(72,'4138','Fall 2013'),(73,'4142','Spring 2014'),(74,'4145','Summer 2014'),(75,'4148','Fall 2014'),(76,'4152','Spring 2015'),(77,'4155','Summer 2015'),(78,'4158','Fall 2015'),(79,'4162','Spring 2016'),(80,'4165','Summer 2016'),(81,'4168','Fall 2016'),(82,'4172','Spring 2017'),(83,'4175','Summer 2017'),(84,'4178','Fall 2017'),(85,'4182','Spring 2018'),(86,'4185','Summer 2018'),(87,'4188','Fall 2018'),(88,'4192','Spring 2019'),(89,'4195','Summer 2019'),(90,'4198','Fall 2019'),(91,'4202','Spring 2020'),(92,'4205','Summer 2020'),(93,'4208','Fall 2020'),(94,'4212','Spring 2021'),(95,'4215','Summer 2021'),(96,'4218','Fall 2021'),(97,'4222','Spring 2022'),(98,'4225','Summer 2022'),(99,'4228','Fall 2022'),(100,'4232','Spring 2023'),(101,'4235','Summer 2023'),(102,'4238','Fall 2023'),(103,'4242','Spring 2024'),(104,'4245','Summer 2024'),(105,'4248','Fall 2024'),(106,'4252','Spring 2025'),(107,'4255','Summer 2025'),(108,'4258','Fall 2025'),(109,'4262','Spring 2026'),(110,'4265','Summer 2026'),(111,'4268','Fall 2026'),(112,'4272','Spring 2027'),(113,'4275','Summer 2027'),(114,'4278','Fall 2027'),(115,'4282','Spring 2028'),(116,'4285','Summer 2028'),(117,'4288','Fall 2028'),(118,'4292','Spring 2029'),(119,'4295','Summer 2029'),(120,'4298','Fall 2029'),(121,'4302','Spring 2030'),(122,'4305','Summer 2030'),(123,'4308','Fall 2030'),(124,'4312','Spring 2031'),(125,'4315','Summer 2031'),(126,'4318','Fall 2031'),(127,'4322','Spring 2032'),(128,'4325','Summer 2032'),(129,'4328','Fall 2032'),(130,'4332','Spring 2033'),(131,'4335','Summer 2033'),(132,'4338','Fall 2033'),(133,'4342','Spring 2034'),(134,'4345','Summer 2034'),(135,'4348','Fall 2034'),(136,'4352','Spring 2035'),(137,'4355','Summer 2035'),(138,'4358','Fall 2035'),(139,'4362','Spring 2036'),(140,'4365','Summer 2036'),(141,'4368','Fall 2036'),(142,'4372','Spring 2037'),(143,'4375','Summer 2037'),(144,'4378','Fall 2037'),(145,'4382','Spring 2038'),(146,'4385','Summer 2038'),(147,'4388','Fall 2038'),(148,'4392','Spring 2039'),(149,'4395','Summer 2039'),(150,'4398','Fall 2039'),(151,'4402','Spring 2040'),(152,'4405','Summer 2040'),(153,'4408','Fall 2040');
/*!40000 ALTER TABLE `iuie_academic_terms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-24 10:08:01
