from django.shortcuts import get_object_or_404, render, redirect, HttpResponse
from django.contrib import messages
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import ClassData, Enrollments
from django.utils.encoding import smart_str
from django.db import connection
from django.http import JsonResponse
import csv


# Create your views here.
def index(request):
    # courses = Course.objects.all()
    
    termList = [str(classData.ACAD_TERM_CD) for classData in ClassData.objects.all()]
    campusList = [str(classData.CAMPUS) for classData in ClassData.objects.all()]

    terms = set(termList)
    campuses = set(campusList)
    
    context = {
      'terms' : terms,
      'campuses' : campuses
    }
    return render(request, 'courses/search.html', context)

def courseSearch(request):
    #queryset_list = ClassData.objects.all()
    
    #cursor = connection.cursor()
    #cursor.execute("SELECT a."'"CRS_ID"'",  a."'"ACAD_TERM_CD"'" from courses_classdata a inner join enrollments_Enrollments b  on a."'"CRS_ID"'" = b."'"CRS_ID"'"")
    #rows = cursor.fetchall()
    
    #queryset_list = []
    # print(rows)

    # very important
    '''for row in rows:
        print(row)
        for i in range(0, len(row)):
            print(row[i])'''

    '''cursor.execute(" SELECT classdata."'"CRS_ID"'", enrollment."'"CRS_DESC"'", classdata."'"ACAD_TERM_CD"'", classdata."'"CAMPUS"'", .\
        classdata."'"CLS_INSTR_NM"'", classdata."'"ENROLLMENT_CAP"'", classdata."'"ENROLLMENT_TOTAL"'",   .\
        classdata."'"ENROLLMENT_CAP"'" - classdata."'"ENROLLMENT_TOTAL"'" ""Calculated Remaning"" .\
        from courses_classdata classdata .\
        inner join enrollments_Enrollments enrollment .\
        on classdata."'"CRS_ID"'" = enrollment."'"CRS_ID"'" ")'''

    '''for obj in queryset_list:
        #print(obj.CRS_ID)
        #courseID = obj.CRS_ID
        #print(courseID[0])
        #obj.enrollment.add()

        enroll = Enrollments.objects.all().filter(CRS_ID = obj.CRS_ID)
        obj.enrollment = enroll
        #print(enrollment)
        #print(obj.CRS_ID + " " + obj.enrollment.CRS_DESC)
    
        # x = Enrollments.objects.filter(CRS_ID = 93494)
        # for a in x:
        # print(a.CLS_NBR)

        i = 0
        classdata = ClassData
        classdata.CLS_NBR = row[i]
        i  = i+1
        classdata.CRS_ID = row[i]
        i  = i+1
        classdata.ACAD_TERM_CD = row[i]
        i  = i+1
        classdata.CLS_INSTR_NM = row[i]
        i  = i+1
        classdata.CAMPUS = row[i]
        i  = i+1
        classdata.ENROLLMENT_CAP = row[i] 
        i  = i+1
        classdata.ENROLLMENT_TOTAL = row[i]'''

    #print("hello")
    #print(coursenumber)


    sqlQuery = "SELECT classdata."'"id"'", classdata."'"CRS_ID"'", enrollment."'"CRS_DESC"'", classdata."'"CAMPUS"'", classdata."'"ACAD_TERM_CD"'", \
        classdata."'"CLS_INSTR_NM"'", classdata."'"ENROLLMENT_CAP"'", classdata."'"ENROLLMENT_TOTAL"'",  \
        classdata."'"ENROLLMENT_CAP"'" - classdata."'"ENROLLMENT_TOTAL"'" \
        from courses_classdata classdata \
        inner join enrollments_Enrollments enrollment \
        on classdata."'"CRS_ID"'" = enrollment."'"CRS_ID"'" "
    
    coursenumber = request.GET.get('coursenumber', None)
    coursename = request.GET.get('coursename', None)
    campusinstructions = request.GET.get('campusinstructions', None)
    term = request.GET.get('term', None)

    if coursenumber:
        sqlQuery = sqlQuery + " AND classdata."'"CRS_ID"'" = " + coursenumber 
            
    if coursename:
        sqlQuery = sqlQuery + " AND enrollment."'"CRS_DESC"'" = '" + coursename + "'"

    if campusinstructions:
        sqlQuery = sqlQuery + " AND classdata."'"CAMPUS"'" = '" + campusinstructions + "'"

    if term:
        sqlQuery = sqlQuery + " AND classdata."'"ACAD_TERM_CD"'" = " + term
    
    cursor = connection.cursor()
    cursor.execute(sqlQuery)
    rows = cursor.fetchall()
    
    queryset_list = []
    for row in rows:
        queryset_list.append(row)
    
    termList = [str(classData.ACAD_TERM_CD) for classData in ClassData.objects.all()]
    campusList = [str(classData.CAMPUS) for classData in ClassData.objects.all()]

    terms = set(termList)
    campuses = set(campusList)

    '''#print(queryset_list.query)
    paginator = Paginator(queryset_list, 10)
    # page = request.GET.get('page')
    # paged_listings = paginator.get_page(page) 
    page = int(request.GET.get('page', '1'))
    courseDetails = paginator.page(page)
    # Get the index of the current page
    # edited to something easier without index
    # This value is maximum index of your pages, so the last page - 1
    # You want a range of 7, so lets calculate where to slice the list
    # Get our new page range. In the latest versions of Django page_range returns
    # an iterator. Thus pass it to list, to make our slice possible again.
    
    index = courseDetails.number - 1  
    max_index = len(paginator.page_range)
    start_index = index - 3 if index >= 3 else 0
    end_index = index + 3 if index <= max_index - 3 else max_index
    page_range = list(paginator.page_range)[start_index:end_index]

    context = {
        'terms' : terms,
        'campuses' : campuses,
        'courses' : courseDetails,
        'page_range': page_range,
        'values': request.GET,
    }'''
    
    context = {
        'terms' : list(terms),
        'campuses' : list(campuses),
        'courses' : queryset_list,
        'values': request.GET
    }

    #print("hello 1")
    #return render(request, 'courses/search.html', context)
    
    #print(context)
    #return render(request, 'courses/search.html', { 'context': context })
    
    return JsonResponse(context)


def courseDetailView(request, course_id):
    #course = get_object_or_404(Course, pk=course_id)
    #courseDetail = ClassData.objects.all().filter(CRS_ID__iexact=str(course_id))
    #print(courseDetail.ClassData.CLS_NBR + " " + courseDetail.ClassData.CRS_ID)
    #for x in courseDetail:
    #print(x.CLS_NBR)
    
    print("Hello")
    print(course_id)

    termList = [str(classData.ACAD_TERM_CD) for classData in ClassData.objects.all()]
    terms = set(termList)
    
    context = {
        'terms' : list(terms),
        'courseId' : course_id
    }
    
    return render(request, 'courses/courseDetailedView.html', context)
    #return JsonResponse(context)
    #return HttpResponse(request, 'courses/courseDetailedView.html', context)
