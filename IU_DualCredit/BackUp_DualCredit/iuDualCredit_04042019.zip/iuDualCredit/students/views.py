from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import Student

# Create your views here.
def index(request):
    # courses = Course.objects.all()
    
    #paginator = Paginator(courses, 10)
    #page = request.GET.get('page')
    #paged_listings = paginator.get_page(page)

    #context = {
        #'courses' : paged_listings
        # 'courses' : courses
    #}
    #return render(request, 'courses/search.html',context)
    return render(request, 'students/search.html')


def studentSearch(request):
    queryset_list = Student.objects.all()
    
    if 'user_name' in request.GET:
        user_name = request.GET['user_name']
        if user_name:
            queryset_list = queryset_list.filter(username__icontains=user_name) 

    if 'uid' in request.GET:
        uid = request.GET['uid']
        if uid:
            queryset_list = queryset_list.filter(uid__iexact=uid) 

    if 'first_name' in request.GET:
        first_name = request.GET['first_name']
        if first_name:
            queryset_list = queryset_list.filter(firstname__iexact=first_name) 

    if 'last_name' in request.GET:
        last_name = request.GET['last_name']
        if last_name:
            queryset_list = queryset_list.filter(lastname__iexact=last_name) 

    if 'campus_of_enrollment' in request.GET:
        campus_of_enrollment = request.GET['campus_of_enrollment']
        if campus_of_enrollment:
            queryset_list = queryset_list.filter(campusofenrollment__iexact=campus_of_enrollment)
    
    if 'student_type' in request.GET:
        student_type = request.GET['student_type']
        if student_type:
            queryset_list = queryset_list.filter(studenttype__iexact=student_type) 

    if 'dc_partner' in request.GET:
        dc_partner = request.GET['dc_partner']
        if dc_partner:
            queryset_list = queryset_list.filter(dcpartner__iexact=dc_partner)     

    #paginator = Paginator(queryset_list, 10)
    #page = request.GET.get('page')
    #paged_listings = paginator.get_page(page)

    context = {
        #'students' : paged_listings
        'students': queryset_list,
        'values': request.GET
    }
    return render(request, 'students/search.html', context)


def studentDetailedView(request, student_uid):
    #student = get_object_or_404(Student, pk=student_uid)
    #context = {
    #    'student' : student,
    #    'comments' : comments,
    #    ''
    #}
    #return render(request, 'students/studentDetailedView.html', context)
    return render(request, 'students/studentDetailedView.html')