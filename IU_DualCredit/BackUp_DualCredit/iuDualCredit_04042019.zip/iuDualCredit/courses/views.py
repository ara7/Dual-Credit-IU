from django.shortcuts import get_object_or_404, render, redirect, HttpResponse
from django.contrib import messages
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import ClassData, Enrollments
from django.utils.encoding import smart_str
from django.db import connection
import csv


# Create your views here.
def index(request):
    # courses = Course.objects.all()
    
    termList = [str(classData.ACAD_TERM_CD) for classData in ClassData.objects.all()]
    campusList = [str(classData.CAMPUS) for classData in ClassData.objects.all()]

    terms = set(termList)
    campuses = set(campusList)
    
    context = {
      'terms' : terms,
      'campuses' : campuses
    }
    return render(request, 'courses/search.html', context)

def courseSearch(request):
    # queryset_list = ClassData.objects.all()
    
    #cursor = connection.cursor()
    #cursor.execute("SELECT a."'"CRS_ID"'",  a."'"ACAD_TERM_CD"'" from courses_classdata a inner join enrollments_Enrollments b  on a."'"CRS_ID"'" = b."'"CRS_ID"'"")
    #rows = cursor.fetchall()
    
    queryset_list = []
    # print(rows)

    # very important
    '''for row in rows:
        print(row)
        for i in range(0, len(row)):
            print(row[i])'''

    '''cursor.execute(" SELECT classdata."'"CRS_ID"'", enrollment."'"CRS_DESC"'", classdata."'"ACAD_TERM_CD"'", classdata."'"CAMPUS"'", .\
        classdata."'"CLS_INSTR_NM"'", classdata."'"ENROLLMENT_CAP"'", classdata."'"ENROLLMENT_TOTAL"'",   .\
        classdata."'"ENROLLMENT_CAP"'" - classdata."'"ENROLLMENT_TOTAL"'" ""Calculated Remaning"" .\
        from courses_classdata classdata .\
        inner join enrollments_Enrollments enrollment .\
        on classdata."'"CRS_ID"'" = enrollment."'"CRS_ID"'" ")'''


    sqlQuery = "SELECT classdata."'"CRS_ID"'", enrollment."'"CRS_DESC"'", classdata."'"CAMPUS"'", \
        classdata."'"CLS_INSTR_NM"'", classdata."'"ENROLLMENT_CAP"'", classdata."'"ENROLLMENT_TOTAL"'",  \
        classdata."'"ENROLLMENT_CAP"'" - classdata."'"ENROLLMENT_TOTAL"'" \
        from courses_classdata classdata \
        inner join enrollments_Enrollments enrollment \
        on classdata."'"CRS_ID"'" = enrollment."'"CRS_ID"'" "

    if 'coursenumber' in request.GET:
        coursenumber = request.GET['coursenumber']
        if coursenumber:
            #print(coursenumber)
            queryset_list = queryset_list.filter(CRS_ID__iexact=coursenumber)

    if 'coursename' in request.GET:
        coursename = request.GET['coursename']
        if coursename:
            print(coursename)
            queryset_list = queryset_list.filter(enrollment__CRS_DESC__icontains=coursename)

    if 'campusinstructions' in request.GET:
        campusinstructions = request.GET['campusinstructions']
        if campusinstructions:
            queryset_list = queryset_list.filter(CAMPUS__iexact=campusinstructions) 

    if 'term' in request.GET:
        term = request.GET['term']
        if term:
            queryset_list = queryset_list.filter(ACAD_TERM_CD__iexact=term)
            

    cursor = connection.cursor()
    cursor.execute("  ")

    rows = cursor.fetchall()

    for row in rows:
        print(row)
        queryset_list.append(row)

    '''for obj in queryset_list:
        #print(obj.CRS_ID)
        #courseID = obj.CRS_ID
        #print(courseID[0])
        #obj.enrollment.add()

        enroll = Enrollments.objects.all().filter(CRS_ID = obj.CRS_ID)
        obj.enrollment = enroll
        #print(enrollment)
        #print(obj.CRS_ID + " " + obj.enrollment.CRS_DESC)
    
    #x = Enrollments.objects.filter(CRS_ID = 93494)
    #for a in x:
    #   print(a.CLS_NBR)'''
    

    termList = [str(classData.ACAD_TERM_CD) for classData in ClassData.objects.all()]
    campusList = [str(classData.CAMPUS) for classData in ClassData.objects.all()]

    terms = set(termList)
    campuses = set(campusList)

    

    #print(queryset_list.query)

    paginator = Paginator(queryset_list, 10)
    # page = request.GET.get('page')
    # paged_listings = paginator.get_page(page) 
    
    page = int(request.GET.get('page', '1'))
    courseDetails = paginator.page(page)
    
    # Get the index of the current page
    # edited to something easier without index
    # This value is maximum index of your pages, so the last page - 1
    # You want a range of 7, so lets calculate where to slice the list
    # Get our new page range. In the latest versions of Django page_range returns
    # an iterator. Thus pass it to list, to make our slice possible again.
    
    index = courseDetails.number - 1  
    max_index = len(paginator.page_range)
    start_index = index - 3 if index >= 3 else 0
    end_index = index + 3 if index <= max_index - 3 else max_index
    page_range = list(paginator.page_range)[start_index:end_index]

    context = {
        'terms' : terms,
        'campuses' : campuses,
        'courses' : courseDetails,
        'page_range': page_range,
        'values': request.GET,
        'row' : row
    }
    return render(request, 'courses/search.html', context)

def courseDetailView(request, course_id):
    #course = get_object_or_404(Course, pk=course_id)
    courseDetail = ClassData.objects.all().filter(CRS_ID__iexact=str(course_id))
    #print(courseDetail.ClassData.CLS_NBR + " " + courseDetail.ClassData.CRS_ID)
    
    for x in courseDetail:
        print(x.CLS_NBR)
    
    context = {
        'courseDetail' : courseDetail
    }
    return render(request, 'courses/courseDetailedView.html', context)