from DAL import dataAdapter 

def termList():
    sqlTermList = "SELECT Distinct enrollment.ACAD_TERM_CD FROM  iuie_enrollments enrollment Order By 1 " 
    data = dataAdapter.execute(sqlTermList)
    termList = dataAdapter.ConvertToList(data, 0)    
    return termList



def courseList():
    sqlCourseList = "SELECT DISTINCT enrollments.CRS_SUBJ_CD, CONCAT(enrollments.CRS_SUBJ_CD,':', enrollments.CRS_CATLG_NBR) \
                    FROM iuie_enrollments enrollments \
                    Order By 1"; 
    data = dataAdapter.execute(sqlCourseList)
    crsList = dataAdapter.ConvertToList(data,1) 
    return crsList


def enrollmentList(term, course, funding):
    
    if course:
        crsSubjCd = (course.split(':')[0]).strip()
        CrsCatlgNbr = (course.split(':')[1]).strip()

    sqlEnrollmentQuery = "SELECT enrollments.ACAD_TERM_CD, CONCAT(enrollments.CRS_SUBJ_CD, ':' ,enrollments.CRS_CATLG_NBR), \
		                date_format(enrollments.STu_ENRL_ADD_DT, '%M %D %Y'), enrollments.CLS_INSTR_NM \
                        from iuie_enrollments enrollments Where 1 = 1 "
    
    if term:
        sqlEnrollmentQuery = sqlEnrollmentQuery + " AND enrollments.ACAD_TERM_CD = " + term 
    if course:
        sqlEnrollmentQuery = sqlEnrollmentQuery + " AND enrollments.CRS_SUBJ_CD = '" + crsSubjCd + "' AND enrollments.CRS_CATLG_NBR = '" + CrsCatlgNbr + "'"

    sqlEnrollmentQuery = sqlEnrollmentQuery + " Order by 1 "

    #print(sqlEnrollmentQuery)

    data = dataAdapter.execute(sqlEnrollmentQuery)

    return data