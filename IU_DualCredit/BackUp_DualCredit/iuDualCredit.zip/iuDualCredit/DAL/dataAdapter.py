from django.db import connection

def execute(sqlQuery):
    cursor = connection.cursor()
    cursor.execute(sqlQuery)
    sqlList = cursor.fetchall()
    return sqlList

def executeOne(sqlQuery):
    cursor = connection.cursor()
    cursor.execute(sqlQuery)
    sqlList = cursor.fetchone()
    return sqlList


def ConvertToList(data, index):
    queryList = []
    for row in data:
        rowList = list(row)
        queryList.append(rowList[index])
    return queryList
