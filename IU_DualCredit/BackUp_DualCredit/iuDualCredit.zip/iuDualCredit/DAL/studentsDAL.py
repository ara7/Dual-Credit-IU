from DAL import dataAdapter


def campusList():
    sqlCampusList = "SELECT Distinct applications.INST_CD FROM  iuie_applications applications Order By 1 " 
    data = dataAdapter.execute(sqlCampusList)
    CampusList = dataAdapter.ConvertToList(data, 0)    
    return CampusList


def dcPartnerList():
    sqldcPartnerList = "SELECT Distinct dc_partner FROM funding_applications Order By 1 " 
    data = dataAdapter.execute(sqldcPartnerList)
    dcPartnerList = dataAdapter.ConvertToList(data, 0)    
    return dcPartnerList


def studentsList(userName, UID, firstName, lastName, campusOfEnrollment, studentType, dcPartner, currentlyEnrolled, pendingEnrollmentRequests):
    
    sqlStudentQuery = " SELECT PRSN_UNIV_ID, Concat(PRSN_PREF_1ST_NM,' ', PRSN_PREF_MID_NM, ' ',  PRSN_PREF_LAST_NM) 'Student Name', \
                        DATE_FORMAT(ROW_EFF_DT,'%b %d %Y'), CREDITS_COMPLETED, PRSN_GDS_CMP_EMAIL_ADDR, INST_CD \
                        from iuie_applications applications \
                        Where 1 = 1 "
    
    if userName:
        sqlStudentQuery = sqlStudentQuery + " AND ( Lower(applications.PRSN_PREF_1ST_NM) Like Lower('%" + userName + "%') OR Lower(applications.PRSN_PREF_MID_NM) Like Lower('%" + userName + "%') OR Lower(applications.PRSN_PREF_LAST_NM) Like Lower('%" + userName + "%') ) "

    if UID:
        sqlStudentQuery = sqlStudentQuery + " AND Lower(applications.PRSN_UNIV_ID) Like ('%" + UID + "%')"

    if firstName:
        sqlStudentQuery = sqlStudentQuery + " AND Lower(applications.PRSN_PREF_1st_NM) Like Lower('%" + firstName + "%')"

    if lastName:
        sqlStudentQuery = sqlStudentQuery + " AND Lower(applications.PRSN_PREF_LAST_NM) Like Lower('%" + lastName + "%')"

    if campusOfEnrollment:
        sqlStudentQuery = sqlStudentQuery + " AND Lower(applications.INST_CD) = Lower('" + campusOfEnrollment + "')"


    ## Important

    # if studentType:
    #     sqlCoursesQuery = sqlCoursesQuery + " AND Lower(applications.INST_CD) = Lower('" + studentType + "')"

    # if dcPartner:
    #     sqlStudentQuery = sqlStudentQuery + " AND Lower(applications.INST_CD) = Lower('" + dcPartner + "')"
    
    # if currentlyEnrolled:
    #     sqlCoursesQuery = sqlCoursesQuery + " AND applications.ACAD_TERM_CD = '" + currentlyEnrolled + "'"

    # if pendingEnrollmentRequests:
    #     sqlCoursesQuery = sqlCoursesQuery + " AND applications.ACAD_TERM_CD = '" + pendingEnrollmentRequests + "'"

    sqlStudentQuery = sqlStudentQuery + " Order by 1 "

    data = dataAdapter.execute(sqlStudentQuery)
    
    #print(sqlStudentQuery)
    #print(data)
    
    return data


def studentDetailView(UID):    
    
    # Student Details
    #print(UID)
    sqlStudentDetails = " SELECT DISTINCT Concat(PRSN_PREF_1ST_NM,' ', PRSN_PREF_MID_NM, ' ',  PRSN_PREF_LAST_NM) 'Student Name',  PRSN_UNIV_ID, \
                        DATE_FORMAT(PRSN_BIRTH_DT,'%b %d %Y') 'Birth Date',  \
                        funding.legal_sex, funding.gender_identity, funding.phone, funding.contact_preference, applications.PRSN_GDS_CMP_EMAIL_ADDR \
                        FROM iuie_applications applications \
                        Inner Join funding_applications funding \
                        on Trim(leading '0' from applications.PRSN_UNIV_ID) = funding.reported_univ_id \
                        Where Trim(leading '0' from applications.PRSN_UNIV_ID) = '"  + UID + "'"

    dataStudentDetails = dataAdapter.executeOne(sqlStudentDetails)

    # Former Names
    sqlStudentFormerNames = " SELECT former_name_1 \
                                from funding_applications funding \
                                where funding.reported_univ_id = Trim(leading '0' from '" + UID + "') \
                                union \
                                SELECT former_name_2 \
                                from funding_applications funding \
                                where funding.reported_univ_id = Trim(leading '0' from '" + UID + "')  \
                                union \
                                SELECT former_name_3 \
                                from funding_applications funding \
                                where funding.reported_univ_id = Trim(leading '0' from '" + UID + "') \
                                union \
                                SELECT former_name_4 \
                                from funding_applications funding \
                                where funding.reported_univ_id = Trim(leading '0' from '" + UID + "') \
                                union \
                                SELECT former_name_5 \
                                from funding_applications funding \
                                where funding.reported_univ_id = Trim(leading '0' from '" + UID + "')"
    
    dataStudentFormerNames = dataAdapter.execute(sqlStudentFormerNames)
    
   
    # Qualitrics Tabs
    sqlStudentQualitricsTabsHeader = "Select enrollments.ACAD_TERM_CD from iuie_enrollments enrollments Where enrollments.PRSN_UNIV_ID = Trim(leading '0' from '" + UID + "')"
    dataStudentQualitricsTabsHeader = dataAdapter.execute(sqlStudentQualitricsTabsHeader)
    
    # print(sqlStudentQualitricsTabsHeader)
    # print(dataStudentQualitricsTabsHeader)
    
    # Qualitric Data
    # sqlStudentQualitricsTabsData = " "
    # dataStudentQualitricsTabsData = dataAdapter.execute(sqlStudentQualitricsTabsData)

    # Enrollment History Data
    sqlStudentEnrollmentHistory = "Select Distinct enrollments.CRS_DESC, enrollments.CLS_NBR, enrollments.ACAD_TERM_CD, enrollments.STU_ENRL_STAT_REAS_CD, \
                                    enrollments.CRS_OFCL_GRD_CD, applications.CREDITS_COMPLETED \
                                    from iuie_enrollments enrollments \
                                    Inner Join iuie_classes classdata \
                                    on classdata.CRS_ID = enrollments.CRS_ID AND classdata.ACAD_TERM_CD = enrollments.ACAD_TERM_CD \
                                    Inner Join iuie_applications applications \
                                    on enrollments.PRSN_UNIV_ID  = Trim(leading '0' from applications.PRSN_UNIV_ID) \
                                    Where enrollments.PRSN_UNIV_ID = Trim(leading '0' from '" + UID + "') \
                                    Order By 2,3 " 

    dataStudentEnrollmentHistory = dataAdapter.execute(sqlStudentEnrollmentHistory)
    
    # Course Request
    sqlStudentCourseRequest =  "Select enrollments.STU_ENRL_ADD_DT,  enrollments.CRS_ID, enrollments.CLS_NBR, enrollments.STU_ENRL_DRP_DT \
                                from iuie_enrollments enrollments \
                                Where enrollments.PRSN_UNIV_ID = Trim(leading '0' from '" + UID + "')"

    dataStudentCourseRequest = dataAdapter.execute(sqlStudentCourseRequest)
    

    # Comments
    # sqlStudentCommentsData = " "
    # dataStudentCommentsData = dataAdapter.execute(sqlStudentCommentsData)
    
    return dataStudentDetails, dataStudentFormerNames, dataStudentQualitricsTabsHeader, dataStudentEnrollmentHistory, dataStudentCourseRequest





def studentYearWiseQualitricsData(UID, academicYear): 
    # Change the Query
    sqlStudentQualitricsData = " SELECT enrollments.ACAD_TERM_CD \
                                from iuie_enrollments enrollments \
                                where enrollments.PRSN_UNIV_ID = Trim(leading '0' from '" + UID + "')"
    
    dataStudentQualitricsData = dataAdapter.execute(sqlStudentQualitricsData)
    StudentQualitricsYearDataList = dataAdapter.ConvertToList(dataStudentQualitricsData, 0)    
    return StudentQualitricsYearDataList