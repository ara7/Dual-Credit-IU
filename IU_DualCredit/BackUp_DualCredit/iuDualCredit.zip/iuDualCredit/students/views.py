from django.shortcuts import get_object_or_404, render, redirect, HttpResponse
from django.contrib import messages
from django.core.mail import send_mail
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import Student, ClassData
from django.db import connection
from django.http import JsonResponse
from DAL import studentsDAL
import csv

# Create your views here.
def index(request):
    
    campusList = studentsDAL.campusList()
    dcPartnerList = studentsDAL.dcPartnerList()

    context = {
      'campuses' : campusList,
      'dcPartners' : dcPartnerList
    }

    return render(request, 'students/search.html', context)


def studentSearch(request):
   
    username = request.GET.get('username', None)
    uid = request.GET.get('uid', None)
    firstname = request.GET.get('firstname', None)
    lastname = request.GET.get('lastname', None)
    campusOfenrollment = request.GET.get('campusOfenrollment', None)
    studentType = request.GET.get('studentType', None)
    dcPartner = request.GET.get('dcPartner', None)
    currentlyEnrolled = request.GET.get('currentlyEnrolled', None)
    pendingEnrollmentReq = request.GET.get('pendingEnrollmentReq', None)
    
    campusList = studentsDAL.campusList()
    dcPartnerList = studentsDAL.dcPartnerList()

    studentsList = studentsDAL.studentsList(username, uid, firstname, lastname, campusOfenrollment, studentType, dcPartner, currentlyEnrolled, pendingEnrollmentReq)

    context = {
        'campuses' : campusList,
        'dcPartners' : dcPartnerList,
        'studentDetails': studentsList
    }
    
    return JsonResponse(context)


def studentDetailView(request, student_uid):

    StudentDetailList, StudentFormerNamesList, studentQualitricsTabHeaderList, studentEnrollmentHistoryList, StudentCourseRequest = studentsDAL.studentDetailView(str(student_uid))

    studentDetailsDict = {}
    if StudentDetailList:
        studentDetailsDict['Student Name'] = StudentDetailList[0]
        studentDetailsDict['User Name'] = 'None'
        studentDetailsDict['UID'] = StudentDetailList[1]
        studentDetailsDict['Date of Birth'] = StudentDetailList[2]
        studentDetailsDict['Citizenship'] = 'None'
        studentDetailsDict['Student Type'] = 'None'

        studentDetailsDict['Legal Sex'] = StudentDetailList[3]
        studentDetailsDict['Gender Identity'] = StudentDetailList[4]
        studentDetailsDict['Phone Number'] = StudentDetailList[5]
        studentDetailsDict['Contact Method'] = StudentDetailList[6]
        studentDetailsDict['Email'] = StudentDetailList[7]

        studentDetailsDict['Current Mailing Address'] = 'None'
        studentDetailsDict['Permanent Mailing Address'] = 'None'
        studentDetailsDict['Residency'] = 'None'

        studentDetailsDict['Documents Send under another name'] = 'None'

    qualitricsTabHeaderList = []
    for qualitricsTabHeader in studentQualitricsTabHeaderList:
        qualitricsTabHeaderList.append(qualitricsTabHeader[0])

    context = {
        'studentUid' : student_uid,
        'studentDetailsDict' : studentDetailsDict,
        'studentFormerNamesList' : StudentFormerNamesList,
        'tabsLists' : qualitricsTabHeaderList,
        # 'tabQualitricsData' : studentQualitricsdata,
        'enrollmentHistoryDetailsList' : studentEnrollmentHistoryList,
        'courseDetailsList' : StudentCourseRequest
        #'commentsList' : commentsList
    }

    return render(request, 'students/studentDetailedView.html', context)


def studentQualitricsYearWiseDetails(request):
    
    if request.method == 'POST':
        studentUid = request.POST['studentUid']
        academicYear = request.POST['academicYear']

    #print(studentUid)
    #print(academicYear)

    #studentUid = studentUid
    StudentQualitricsDataList = studentsDAL.studentYearWiseQualitricsData(studentUid,academicYear)
    
    #print(StudentQualitricsDataList)

    context = {
        'StudentQualitricsDataList' : StudentQualitricsDataList,
    }
    
    return JsonResponse(context)


def exportcsv(request):
    
    if request.method == 'POST':
        username = request.POST['username']
        uid = request.POST['uid']
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        campusOfenrollment = request.POST['campusOfenrollment']
        studentType = request.POST['studentType']
        dcPartner = request.POST['dcPartner']
        currentlyEnrolled = request.POST['currentlyEnrolled']
        pendingEnrollmentReq = request.POST['pendingEnrollmentReq']

    studentsList = studentsDAL.studentsList(username, uid, firstname, lastname, campusOfenrollment, studentType, dcPartner, currentlyEnrolled, pendingEnrollmentReq)
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=students.csv'
    writer = csv.writer(response, delimiter=',')

    response.write(u'\ufeff'.encode('utf8'))

    writer.writerow(['PRSN_UNIV_ID','Student Name','Effective_Date','CREDITS_COMPLETED','PRSN_GDS_CMP_EMAIL_ADDR','INST_CD'])

    for obj in studentsList:
        writer.writerow([ obj[0], obj[1], obj[2], obj[3], obj[4], obj[5] ])
    
    #print(response)

    return response