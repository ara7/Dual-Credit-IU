from django.shortcuts import render, HttpResponse
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import Enrollments
from django.utils.encoding import smart_str
from django.db import connection
from django.http import JsonResponse
import csv
from DAL import enrollmentsDAL 


def index(request):
    
    termList = enrollmentsDAL.termList()
    courseList = enrollmentsDAL.courseList()
    
    context = {
      'terms' : termList,
      'courses' : courseList
    }
    return render(request, 'enrollments/search.html', context)
    

def search(request):
    
    term = request.GET.get('term', None)
    course = request.GET.get('course', None)
    funding = request.GET.get('funding', None)
    
    termList = enrollmentsDAL.termList()
    courseList = enrollmentsDAL.courseList()
    enrollmentDetailsList = enrollmentsDAL.enrollmentList(term,course,funding)
    
    context = {
        'terms' : termList,
        'courses' : courseList,
        'enrollments' : enrollmentDetailsList,
        'values': request.GET
    }

    return JsonResponse(context)


def exportcsv(request):
    
    if request.method == 'POST':
        term = request.POST['term']
        course = request.POST['course']
        funding = request.POST['funding']

    enrollmentDetailsExportList = enrollmentsDAL.enrollmentList(term,course,funding)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=enrollment.csv'
    writer = csv.writer(response, delimiter=',')

    response.write(u'\ufeff'.encode('utf8'))

    writer.writerow(['ACAD_TERM_CD', 'CRS_SUBJ_CD' , 'CRS_CATLG_NBR', 'STUDENT_ENRL_ADD_DT', 'CLASS_INSTR_NM' ])

    for obj in enrollmentDetailsExportList:
        writer.writerow([ obj[0], obj[1], 'None', obj[2], obj[3] ])
    
    return response