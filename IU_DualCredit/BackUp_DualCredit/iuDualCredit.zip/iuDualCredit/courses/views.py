from django.shortcuts import get_object_or_404, render, redirect, HttpResponse
from django.contrib import messages
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import ClassData, Enrollments
from django.utils.encoding import smart_str
from django.db import connection
from django.http import JsonResponse
import csv
import sys
from DAL import coursesDAL 

# Create your views here.
def index(request):
    
    termList = coursesDAL.termList()
    campusList = coursesDAL.campusList()
    
    context = {
        'terms' : termList,
        'campuses' : campusList
    }
    return render(request, 'courses/search.html', context)


   

def courseSearch(request):
    
    coursenumber = request.GET.get('coursenumber', None)
    coursename = request.GET.get('coursename', None)
    campusinstructions = request.GET.get('campusinstructions', None)
    term = request.GET.get('term', None)

    # print(campusinstructions)
    # print(term)

    coursesList = coursesDAL.coursesList(coursenumber,coursename,campusinstructions,term)
    
    termList = coursesDAL.termList()
    campusList = coursesDAL.campusList()

    context = {
        'terms' : termList,
        'campuses' : campusList,
        'courses' : coursesList,
        'values': request.GET
    }

    return JsonResponse(context)


def courseDetailView(request, courseinfo):
#def courseDetailView(request):
    
    #print("courseDetailView")
    # print(courseinfo)
    #courseinfo = "81192|4188|IUSBA"
    
    courseInformation = courseinfo.split("|")
    courseID = courseInformation[0]
    term = courseInformation[1]
    CampusOfInstruction = courseInformation[2]

    courseDetailsHeader1List, courseDetailsHeader2List, campusSeatsList, StudentDetailsList  = coursesDAL.courseDetailView(courseID,term,CampusOfInstruction)
    
    #Course Details
    courseDetailsDict = {}
    courseDetailsDict['Course Description'] = courseDetailsHeader1List[1]
    courseDetailsDict['Term Offered'] = courseDetailsHeader1List[2]
    courseDetailsDict['Campus of Instruction'] = courseDetailsHeader1List[4]

    courseDetailsDict['Number of Drops'] = courseDetailsHeader2List[3]
    courseDetailsDict['Number of Withdrawals'] = courseDetailsHeader2List[4]
 
    context = {
        'courseDetailsDict' : courseDetailsDict,
        'campusSeatsList' : campusSeatsList,
        'StudentDetailsList' : StudentDetailsList,
        'courseId' : courseID
    }
    
    return render(request, 'courses/courseDetailedView.html', context)
    

def exportcsv(request):
    
    if request.method == 'POST':
        coursenumber = request.POST['coursenumber']
        coursename = request.POST['coursename']
        campusinstructions = request.POST['campusinstructions']
        term = request.POST['term']

    coursesList = coursesDAL.coursesList(coursenumber,coursename,campusinstructions,term)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=enrollment.csv'
    writer = csv.writer(response, delimiter=',')
    response.write(u'\ufeff'.encode('utf8'))

    writer.writerow(['CRS_ID', 'CRS_DESC' , 'ACAD_TERM_CD', 'COI_INST_CD', 'CLS_INSTR_NM', 'ENROLLMENT_CAP', 'ENROLLMENT_TOTAL', 'Calculated_Remaining' ])

    for obj in coursesList:
        writer.writerow([ obj[1], obj[2], obj[3], obj[4], obj[5], obj[6], obj[7], obj[8] ])
        #writer.writerow([ obj.CLS_NBR, obj.CRS_ID, obj.ACAD_TERM_CD, obj.CLS_INSTR_NM, obj.CLS_INSTR_GDS_CMP_EMAIL_ADDR, obj.CAMPUS, obj.ENROLLMENT_CAP, obj.ENROLLMENT_TOTAL ])
    
    #print(response)

    return response