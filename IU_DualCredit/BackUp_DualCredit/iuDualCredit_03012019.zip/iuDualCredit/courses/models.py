from django.db import models
from datetime import datetime

# Create your models here.
class Course(models.Model):
  #realtor = models.ForeignKey(Realtor, on_delete=models.DO_NOTHING)
  
  # card 1
  course_name = models.CharField(max_length=200)
  course_number = models.IntegerField()
  course_description = models.TextField(blank=True)
  term_offered = models.CharField(max_length=200)
  campus_of_instructions = models.CharField(max_length=200)
  no_of_drops = models.IntegerField()
  no_of_withdrawls = models.IntegerField()
  
  # card 2
  campus = models.CharField(max_length=200)
  class_number = models.CharField(max_length=200)
  
  # card 3
  total_seats = models.IntegerField()
  enrolled = models.IntegerField()