from django.shortcuts import get_object_or_404, render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from .models import Course

# from .models import contact

# Create your views here.
def index(request):
    # courses = Course.objects.all()
    
    #paginator = Paginator(courses, 10)
    #page = request.GET.get('page')
    #paged_listings = paginator.get_page(page)

    #context = {
        #'courses' : paged_listings
        # 'courses' : courses
    #}
    #return render(request, 'courses/search.html',context)
    
    return render(request, 'courses/search.html')


def courseSearch(request):
    queryset_list = Course.objects.all()
    
    if 'course_number' in request.GET:
        course_number = request.GET['course_number']
        if course_number:
            queryset_list = queryset_list.filter(coursenumber__icontains=course_number) 

    if 'course_name' in request.GET:
        course_name = request.GET['course_name']
        if course_name:
            queryset_list = queryset_list.filter(course_name__iexact=course_name) 

    if 'campus_instructions' in request.GET:
        campus_instructions = request.GET['campus_instructions']
        if campus_instructions:
            queryset_list = queryset_list.filter(campus_instructions__iexact=campus_instructions) 

    if 'term' in request.GET:
        term = request.GET['term']
        if term:
            queryset_list = queryset_list.filter(term__iexact=term) 

    context = {
        'listings': queryset_list,
        'values': request.GET
    }
    
    return render(request, 'courses/search.html', context)

def courseDetailView(request, course_id):
    #course = get_object_or_404(Course, pk=course_id)
    #context = {
    #    'course' : course
    #}
    #return render(request, 'courses/courseDetailedView.html', context)
    return render(request, 'courses/courseDetailedView.html')