from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='courses'),
    path('search', views.courseSearch, name='search'),
    path('<int:course_id>', views.courseDetailView, name='detail')
]