from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='courses'),
    path('coursesearch', views.courseSearch, name='coursesearch'),
    path('<int:course_id>', views.courseDetailView, name='courseDetail')
    #path('exportcsv', views.exportcsv, name='exportcsv'),
]