from django.db import models
from datetime import datetime

# Create your models here.
class Student(models.Model):
  #realtor = models.ForeignKey(Realtor, on_delete=models.DO_NOTHING)
  student_name = models.CharField(max_length=200)