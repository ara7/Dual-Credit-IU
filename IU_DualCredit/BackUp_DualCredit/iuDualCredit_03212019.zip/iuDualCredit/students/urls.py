from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='students'),
    #path('search', views.studentSearch, name='search'),
    path('<int:student_uid>', views.studentDetailedView, name='detail')
]